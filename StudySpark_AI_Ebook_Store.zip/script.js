// STORE SETUP — edit the values below before publishing.
const PAYMENT_URL = "PASTE_YOUR_PAYMENT_LINK_HERE";
const PRODUCT_PRICE = "[INSERT PRICE]"; // Example format: "₹199" — set your actual price.

const paymentIsConfigured = PAYMENT_URL &&
  PAYMENT_URL !== "PASTE_YOUR_PAYMENT_LINK_HERE" &&
  /^https?:\/\//i.test(PAYMENT_URL);

document.querySelectorAll("[data-buy]").forEach((link) => {
  if (paymentIsConfigured) {
    link.href = PAYMENT_URL;
    link.target = "_self";
    link.removeAttribute("aria-disabled");
  } else {
    link.href = "#product";
    link.setAttribute("aria-describedby", "checkout-note");
    link.addEventListener("click", (event) => {
      event.preventDefault();
      document.getElementById("checkout-note")?.scrollIntoView({behavior:"smooth",block:"center"});
      document.getElementById("checkout-note")?.focus?.();
    });
  }
});

document.querySelectorAll("[data-price]").forEach((node) => {
  node.textContent = PRODUCT_PRICE || "[INSERT PRICE]";
});
const note = document.getElementById("checkout-note");
if (note && paymentIsConfigured) {
  note.textContent = "You’ll continue to the payment checkout. Your ebook is delivered using the configured post-payment setup.";
  note.classList.add("setup-ready");
}
document.getElementById("year").textContent = new Date().getFullYear();

const menuButton = document.querySelector(".menu-toggle");
const nav = document.getElementById("main-nav");
menuButton?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(open));
  menuButton.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  menuButton.textContent = open ? "×" : "☰";
});
nav?.querySelectorAll("a").forEach((item) => item.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton?.setAttribute("aria-expanded","false");
  if (menuButton) { menuButton.textContent = "☰"; menuButton.setAttribute("aria-label","Open navigation"); }
}));
